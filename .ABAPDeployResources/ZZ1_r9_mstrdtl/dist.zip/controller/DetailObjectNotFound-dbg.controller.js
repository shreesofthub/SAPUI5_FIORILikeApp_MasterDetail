sap.ui.define([
    "./BaseController"
], function (BaseController) {
    "use strict";

    return BaseController.extend("r9masterdetail.controller.DetailObjectNotFound", {});
});